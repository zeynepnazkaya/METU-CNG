#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Fish {
	char name[50];
	int weight;
	float length;
	char date[50];
	char city[50];
	struct Fish* next;
};

struct AVL {
	struct Fish *fish;
	struct AVL *left;
	struct AVL *right;
	int height;
};

typedef struct AVL *AVL;
typedef struct Fish *Fish;

int count_fishes(Fish);
AVL double_rotate_with_left(AVL);
AVL single_rotate_with_left(AVL);
AVL double_rotate_with_right(AVL);
AVL single_rotate_with_right(AVL);
int tree_height(AVL);