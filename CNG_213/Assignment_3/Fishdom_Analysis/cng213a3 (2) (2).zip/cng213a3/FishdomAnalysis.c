// Name: Zeynep Naz Kaya
// Student ID:2526481

#include "avltree.h"
#include "avltree.c"

AVL insertFish(char *name, int weight, float length, char *date, char *city, AVL tree) {
	if (tree == NULL) {
		// Create a new AVL node and initialize the fish data
		tree = malloc(sizeof(struct AVL));
		tree->fish = (struct Fish*)malloc(sizeof(struct Fish));

		// Check for memory allocation errors
		if (tree->fish == NULL || tree == NULL) {
			printf("Error: Couldn't insert fish\n");
			exit(1);
		} else {
			// Set the fish data
			strcpy(tree->fish->name, name);
			tree->fish->weight = weight;
			tree->fish->length = length;
			strcpy(tree->fish->date, date);
			strcpy(tree->fish->city, city);

			// Initialize AVL tree properties
			tree->height = 0;
			tree->left = NULL;
			tree->right = NULL;
			tree->fish->next = NULL;
		}
	} else if (tree->fish->weight < weight) {
		// Recursive call to insert into the left subtree
		tree->left = insertFish(name, weight, length, date, city, tree->left);

		// Check and perform AVL rotations if necessary
		if (tree_height(tree->left) - tree_height(tree->right) == 2) {
			if (tree->left->fish->weight < weight) {
				tree = single_rotate_with_left(tree);
			} else {
				tree = double_rotate_with_left(tree);
			}
		}
	} else if (tree->fish->weight > weight) {
		// Recursive call to insert into the right subtree
		tree->right = insertFish(name, weight, length, date, city, tree->right);

		// Check and perform AVL rotations if necessary
		if (tree_height(tree->right) - tree_height(tree->left) == 2) {
			if (tree->left->fish->weight > weight) {
				tree = single_rotate_with_right(tree);
			} else {
				tree = double_rotate_with_right(tree);
			}
		}
	} else {
		// Add a new fish to the fish have the same weight

		// If there is only one fish with the same weight
		if (tree->fish->next == NULL) {
			// Create and initialize the next fish
			tree->fish->next = (struct Fish*)malloc(sizeof(struct Fish));

			// Check for memory allocation errors
			if (tree->fish->next == NULL) {
				printf("Error: Couldn't insert fish!\n");
				exit(1);
			}

			// Set the data for the next fish
			strcpy(tree->fish->next->name, name);
			tree->fish->next->weight = weight;
			tree->fish->next->length = length;
			strcpy(tree->fish->next->date, date);
			strcpy(tree->fish->next->city, city);
			tree->fish->next->next = NULL;
		} else {
			// If there is more than one fish with the same weight

			// Iterate until the found next last fish
			while (tree->fish->next != NULL) {
				tree->fish = tree->fish->next;
			}

			// Create and initialize the next fish
			tree->fish->next = (struct Fish*)malloc(sizeof(struct Fish));
			if (tree->fish->next == NULL) {
				printf("Error: Couldn't insert a fish\n");
				exit(1);
			}

			// Set the data for the next fish
			strcpy(tree->fish->next->name, name);
			tree->fish->next->weight = weight;
			tree->fish->next->length = length;
			strcpy(tree->fish->next->date, date);
			strcpy(tree->fish->next->city, city);
			tree->fish->next->next = NULL;
		}
	}

	// Update the height
	tree->height = tree_height(tree);

	return tree;
}

AVL readData(char *file_name) {
	AVL tree;
	tree = NULL;
	char name[50];
	int weight;
	float length;
	char date[50];
	char city[50];

	FILE *in_file;
	in_file = fopen(file_name, "r");

	if (in_file == NULL) {
		printf("Error has occurred while opening the file!\n");
		exit(-1);
	}

	while (fscanf(in_file, " %[^,],%d,%f,%[^,],%[^\n]", name, &weight, &length, date, city) != EOF) {
        tree = insertFish(name, weight, length, date, city, tree);
    }

    fclose(in_file);

    return tree;
}

void displayIndex(AVL tree) {
	if (tree != NULL) {
		// Traverse the right subtree
		displayIndex(tree->right);

		// Print the current fish and its next fish if exists
		printf("%s,%d,%.2f,%s,%s\n", tree->fish->name, tree->fish->weight, tree->fish->length, tree->fish->date, tree->fish->city);
		if (tree->fish->next != NULL) {
			printf("%s,%d,%.2f,%s,%s\n", tree->fish->next->name, tree->fish->next->weight, tree->fish->next->length, tree->fish->next->date, tree->fish->next->city);
		}

		// Traverse the left subtree
		displayIndex(tree->left);
	}
}

int findMaxWeight(AVL tree) {
    if (tree == NULL) {
        return 0;
    }

    // Recursively find the maximum weight in the left and right subtrees
    int leftMax = findMaxWeight(tree->left);
    int rightMax = findMaxWeight(tree->right);

    int maxWeight = tree->fish->weight;
    if (tree->fish->next != NULL && tree->fish->next->weight > maxWeight) {
        maxWeight = tree->fish->next->weight;
    }

    // Return the maximum weight among the left, right, and current fish
    return (leftMax > rightMax) ? (leftMax > maxWeight ? leftMax : maxWeight) : (rightMax > maxWeight ? rightMax : maxWeight);
}

void inOrderTraverseAndPrintMaxWeight(AVL tree, int maxWeight) {
    if (tree == NULL) {
        return;
    }

    // Traverse the left subtree
    inOrderTraverseAndPrintMaxWeight(tree->left, maxWeight);

    // Print information for each fish with the heaviest weight
    if (tree->fish->weight == maxWeight) {
        printf("%s,%d,%.2f,%s,%s\n", tree->fish->name, tree->fish->weight, tree->fish->length, tree->fish->date, tree->fish->city);
    }

    if (tree->fish->next != NULL && tree->fish->next->weight == maxWeight) {
        printf("%s,%d,%.2f,%s,%s\n", tree->fish->next->name, tree->fish->next->weight, tree->fish->next->length, tree->fish->next->date, tree->fish->next->city);
    }

    // Traverse the right subtree
    inOrderTraverseAndPrintMaxWeight(tree->right, maxWeight);
}


/*
The findMaxWeight function recursively traverses the entire AVL tree to find the maximum weight.
The time complexity of this operation is O(n).
The inOrderTraverseAndPrintMaxWeight function traverses the entire tree in an in-order manner.
For each node, it prints information if the fish has the heaviest weight.
The time complexity of this operation is also O(n).
Therefore, the overall time complexity of the heaviestFish function is O(n).

The current implementation checks the maximum weight during the traversal and prints information if the weight matches the maximum.
A potential improvement could be to perform the traversal once to find the maximum weight and then traverse the tree again to print information. 
This way, we avoid repeatedly checking the maximum weight during the traversal.
This improvement wouldn't change the big-O complexity, but it might reduce constant factors, especially if the tree is large.
*/

void heaviestFish(AVL tree) {
    if (tree == NULL) {
        printf("Tree is empty.\n");
        return;
    }

    int maxWeight = findMaxWeight(tree);

    if (maxWeight == 0) {
        printf("No fish found.\n");
        return;
    }

    inOrderTraverseAndPrintMaxWeight(tree, maxWeight);
}

float findMaxLength(AVL tree) {
    if (tree == NULL) {
        return -1.0;
    }

    // Recursively find the maximum length in the left and right subtrees
    float leftMax = findMaxLength(tree->left);
    float rightMax = findMaxLength(tree->right);

    float maxLength = tree->fish->length;
    if (tree->fish->next != NULL && tree->fish->next->length > maxLength) {
        maxLength = tree->fish->next->length;
    }

    // Return the maximum length among the left, right, and current fish
    return (leftMax > rightMax) ? (leftMax > maxLength ? leftMax : maxLength) : (rightMax > maxLength ? rightMax : maxLength);
}

void inOrderTraverseAndPrintMaxLength(AVL tree, float maxLength) {
    if (tree == NULL) {
        return;
    }

    // Traverse the left subtree
    inOrderTraverseAndPrintMaxLength(tree->left, maxLength);

    // Print information for each fish with the longest length
    if (tree->fish->length == maxLength) {
        printf("%s,%d,%.2f,%s,%s\n", tree->fish->name, tree->fish->weight, tree->fish->length, tree->fish->date, tree->fish->city);
    }

    if (tree->fish->next != NULL && tree->fish->next->length == maxLength) {
        printf("%s,%d,%.2f,%s,%s\n", tree->fish->next->name, tree->fish->next->weight, tree->fish->next->length, tree->fish->next->date, tree->fish->next->city);
    }

    // Traverse the right subtree
    inOrderTraverseAndPrintMaxLength(tree->right, maxLength);
}

/*
The findMaxLength function recursively traverses the entire AVL tree to find the maximum length.
The time complexity of this operation is O(n).
The inOrderTraverseAndPrintMaxLength function traverses the entire tree in an in-order manner.
For each node, it prints information if the fish has the longest length.
The time complexity of this operation is also O(n).
Therefore, the overall time complexity of the longestFish function is O(n).

The current implementation checks the maximum length during the traversal and prints information if the length matches the maximum.
A potential improvement could be to perform the traversal once to find the maximum length and then traverse the tree again to print information. 
This way, we avoid repeatedly checking the maximum length during the traversal.
This improvement wouldn't change the big-O complexity, but it might reduce constant factors, especially if the tree is large.
*/
void longestFish(AVL tree) {
    if (tree == NULL) {
        printf("Tree is empty.\n");
        return;
    }

    float maxLength = findMaxLength(tree);

    if (maxLength == -1.0) {
        printf("No fish found.\n");
        return;
    }

    inOrderTraverseAndPrintMaxLength(tree, maxLength);
}

void displayMenu() {
	printf("\n*******************************************\n");
	printf("Menu\n");
	printf("1. Display the full index of fishdom\n");
	printf("2. Display the heaviest fishes\n");
	printf("3. Display the longest fishes\n");
	printf("4. Exit\n");
	printf("*******************************************\n");
	printf("Enter your option: ");
}


int main(int argc, char *argv[])
{
	if (strcmp(argv[1], "fishes.txt") != 0) {
		printf("%s doesn't exist!\n", argv[1]);
		exit(-1);
	}

	AVL tree;
	tree = readData(argv[1]);
	
	int choise = 0;
	printf("********Welcome to Fishdom Analysis********\n");

	do {
		displayMenu();
		scanf("%d", &choise);

		if (choise == 1) {
			displayIndex(tree);
		} else if (choise == 2) {
			heaviestFish(tree);
		} else if (choise == 3) {
			longestFish(tree);
		} else if (choise == 4) {
			printf("Bye!\n");
		} else {
			printf("Please select one of the given options.\n");
		}
	} while(choise != 4);

	return 0;
}

