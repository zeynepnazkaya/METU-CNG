AVL double_rotate_with_right(AVL k3) {
	k3->right = single_rotate_with_left(k3->right);
	return single_rotate_with_right(k3);
}

AVL double_rotate_with_left(AVL k3) {
	k3->left = single_rotate_with_right(k3->left);
	return single_rotate_with_left(k3);
}

AVL single_rotate_with_right(AVL k1) {
	AVL k2;
	k2 = k1->right;
	k1->right = k2->left;
	k2->left = k1;
	k1->height = tree_height(k1);
	k2->height = tree_height(k2);

	return k2;
}

AVL single_rotate_with_left(AVL k2) {
	AVL k1;
	k1 = k2->left;
	k2->left = k1->right;
	k1->right = k2;
	k2->height = tree_height(k2);
	k1->height = tree_height(k1);

	return k1;
}

int tree_height(AVL tree) {
	int left = 0;
	int right = 0;

	if (tree == NULL) {
		return -1;
	} else {
		left = tree_height(tree->left);
		right = tree_height(tree->right);

		if (left > right) {
			return left + 1;
		} else {
			return right + 1;
		}
	}
}

int count_fishes(Fish fish) {
	int counter = 0;

	while (fish != NULL) {
		counter++;
		fish = fish->next;
	}

	return counter;
}