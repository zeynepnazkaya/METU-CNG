//Tasks Management Simulator-queue.h
//Name & Surname: Zeynep Naz Kaya
//ID: 2526481
#ifndef QUEUE_H
#define QUEUE_H

struct Node
{
    int taskType;
    int arrivalTime;
    int serviceTime;
    int serviceStartTime;
    int ID;
    struct Node *next;
};

struct ListRecord
{
    struct Node *head;
    struct Node *tail;
    int size;
};
typedef struct ListRecord *List;

struct QueueRecord{
    struct Node *head;
    struct Node *tail;
    int sizeOfQueue;
};
typedef struct QueueRecord *Queue;



//Functions Prototypes:
void parseInput(int*,int*,int*,int*,int,char**);
List createTaskList(int,int,int,int);
void initialiseSimulator(Queue, int*, int);
void newTaskFunction(List,Queue);
void accomplishTask(Queue);
void reportStatistics(List, int, int, int*);

#endif


