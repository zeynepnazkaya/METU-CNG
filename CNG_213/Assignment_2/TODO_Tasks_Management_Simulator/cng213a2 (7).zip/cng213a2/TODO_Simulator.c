//Tasks Management Simulator-TODO_Simulator
//Name & Surname: Zeynep Naz Kaya
//ID: 2526481

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "queue.h"
#include "queue.c"

/*
//Here, you can see my structures which is in my queue.h, I commented them here because I think hocam its easy for you.
struct Node
{
    int taskType;
    int arrivalTime;
    int serviceTime;
    int serviceStartTime;
    int ID;
    struct Node *next;
};

struct ListRecord
{
    struct Node *head;
    struct Node *tail;
    int size;
};
typedef struct ListRecord *List;

struct QueueRecord{
    struct Node *head;
    struct Node *tail;
    int sizeOfQueue;
};
typedef struct QueueRecord *Queue;
*/

int main(int argc, char *argv[]) {
    srand(time(NULL));
    int noOfTasks, noOfDevelopper, maxArrivalTime, maxServiceTime;
    int time=0;

    parseInput(&noOfTasks,&noOfDevelopper,&maxArrivalTime,&maxServiceTime,argc,argv);

    List taskList;
    taskList= createTaskList(noOfTasks,noOfDevelopper,maxArrivalTime,maxServiceTime);


    Queue taskQueue;
    taskQueue=(Queue)malloc(sizeof(struct QueueRecord));
    if(taskQueue==NULL){
        printf("Error!\n");
        exit(1);
    }
    int developpers[noOfDevelopper];
    initialiseSimulator(taskQueue,&developpers[0],noOfDevelopper);

    newTaskFunction(taskList,taskQueue);

    accomplishTask(taskQueue);

    reportStatistics(taskList,noOfDevelopper,noOfTasks,&developpers[0]);

    //printf("\nhereMain");
    return 0;
}


//Format: TODO_Simulator 5 2 20 200
//In command line these are char like this:
//argv[0]="TODO_Simulator"
//argv[1]="5"
//argv[2]="2"
//argv[3]="20"
//argv[4]="200"
//They should be converted integers, because of that I used atoi which helps me to convert char to integer
void parseInput(int *noOfTasks, int *noOfDevelopper, int *maxArrivalTime, int *maxServiceTime, int argc, char *argv[])
{
    if(argc>5){
        *noOfTasks = atoi(argv[1]);
        *noOfDevelopper = atoi(argv[2]);
        *maxArrivalTime = atoi(argv[3]);
        *maxServiceTime = atoi(argv[4]);
    }
    else{
        *noOfTasks =5;
        *noOfDevelopper =2;
        *maxArrivalTime =20;
        *maxServiceTime =200;
    }
}


List createTaskList(int noOfTasks, int noOfDevelopper,int maxArrivalTime,int maxServiceTime){
    srand(time(NULL));
    List taskList;

    //I created first node here which is taskList
    taskList=(struct ListRecord*)malloc(sizeof(struct ListRecord));
    if(taskList==NULL){
        printf("\nAllocation Error!\n");
        exit(1);
    }

    taskList->head=(struct Node*)malloc(sizeof(struct Node));
    if(taskList->head==NULL){
        printf("\nAllocation Error!\n");
        exit(1);
    }
    taskList->size=0;
    taskList->head->next=NULL;
    taskList->tail=taskList->head;

    int tmpID=0;

    //Here, I created new Nodes (tmp) equal number with noOfDevelopper
    for(int i=0; i<noOfDevelopper;i++){
        struct Node *tmp;
        tmp=(struct Node*)malloc(sizeof(struct Node));
        if(tmp==NULL)
        {
            printf("\nAllocation Error!\n");
            exit(1);
        }

        //This part, components' values are generated randomly
        //for Task Types,I used 4 because I had 4 priorities.
        tmp->taskType=(rand()% 4)+1;
        tmp->arrivalTime=(rand()% maxArrivalTime)+1;
        tmp->serviceTime=(rand()% maxServiceTime)+1;
        tmp->serviceStartTime=0;
        tmp->ID=tmpID++; //in PDF "(the ID of the first developer is 1, the ID of thesecond developer is 2, … so on)" , because of this I write it like that

        tmp->next=NULL;

        //I connected my first node which is taskList with my new Nodes(tmp)
        taskList->tail->next=tmp;
        taskList->tail=tmp;
    }

    //Here I created 2 pointers, first pointer which is currentArrNode points my first Node (= taskList). Second pointer which is otherArrNode points my second Node (=currentArrNode->next)
    //with using while loops I traverse Nodes and compare them and sorts them by arrival time. (sorting by swapping)
    struct Node *currentArrNode=taskList->head->next;
    struct Node *otherArrNode;
    while(currentArrNode!=NULL){
        otherArrNode=currentArrNode->next;
        while(otherArrNode!=NULL){
            if(currentArrNode->arrivalTime>otherArrNode->arrivalTime){

                int tmpTaskType = currentArrNode->taskType;
                int tmpArrivalTime = currentArrNode->arrivalTime;
                int tmpServiceTime = currentArrNode->serviceTime;
                int tmpServiceStartTime = currentArrNode->serviceStartTime;
                int tmpID = currentArrNode->ID;


                currentArrNode->taskType = otherArrNode->taskType;
                currentArrNode->arrivalTime = otherArrNode->arrivalTime;
                currentArrNode->serviceTime = otherArrNode->serviceTime;
                currentArrNode->serviceStartTime = otherArrNode->serviceStartTime;
                currentArrNode->ID = otherArrNode->ID;

                otherArrNode->taskType = tmpTaskType;
                otherArrNode->arrivalTime = tmpArrivalTime;
                otherArrNode->serviceTime = tmpServiceTime;
                otherArrNode->serviceStartTime = tmpServiceStartTime;
                otherArrNode->ID = tmpID;
            }
            otherArrNode=otherArrNode->next;
        }
        currentArrNode=currentArrNode->next;
    }

    //printf("hereCreate\n");
    return taskList;
}


//This function configures the initial state of developers, indicating their availability for task processing, and initializes a queue structure for tasks, setting up the simulation's initial state.
void initialiseSimulator(Queue taskQueue, int *developpers, int noOfDevelopper)
{
    int i=0;
    /*
    taskQueue=(struct QueueRecord*)malloc(sizeof(struct QueueRecord));
    if(taskQueue==NULL){
        printf("\nOut of memory!");
        exit(1);
    }
     */

    taskQueue->head=(struct Node*)malloc(sizeof(struct Node));

    if(taskQueue->head==NULL)printf("\nFault!\n");

    taskQueue->head->next=NULL;
    taskQueue->tail=taskQueue->head;
    taskQueue->sizeOfQueue=0;

    while (i < noOfDevelopper) {
        //Here, the condition make all developpers available
        *(developpers + i) = 1;
        i++;
    }

    //printf("hereInitialise\n");
}


// Function to report statistics based on the task list
void reportStatistics(List taskList, int noOfDevelopers, int noOfTasks, int *developers) {
    struct Node *tmp;
    tmp = taskList->head->next;

    // Variables for different task priorities and time calculations
    int critical = 0;
    int highPriority = 0;
    int medium = 0;
    int normal = 0;
    float waitTime = 0;
    int maxWaitTime = 0;
    int totalSpentTimeInQueue = 0;

    // Loop through the task list to calculate statistics
    while (tmp != NULL) {
        // Count tasks of different priorities
        if (tmp->taskType == 4) {
            critical++;
        } else if (tmp->taskType == 3) {
            highPriority++;
        } else if (tmp->taskType == 2) {
            medium++;
        } else if (tmp->taskType == 1) {
            normal++;
        }

        // Calculate time spent in the queue
        int spentTimeInQueue = tmp->serviceStartTime - tmp->arrivalTime;
        totalSpentTimeInQueue += spentTimeInQueue;

        // Find maximum waiting time
        if (spentTimeInQueue > maxWaitTime) {
            maxWaitTime = spentTimeInQueue;
        }

        // Count tasks accomplished by each developer
        int i = 0;
        while (i < noOfDevelopers) {
            if (tmp->ID == i) {
                developers[i]++;
                break;
            }
            i++;
        }

        // Calculate total wait time
        waitTime += spentTimeInQueue;
        tmp = tmp->next;
    }

    printf("\n****************Report****************");
    printf("\n*The number of Developers: %d",noOfDevelopers);
    printf("\n*The number of Tasks: %d",noOfTasks);
    printf("\n*Number of Tasks for each Label:");
    // Print task type distribution
    printf("\n\tCritical: %d", critical);
    printf("\n\tHigh priority: %d", highPriority);
    printf("\n\tMedium: %d", medium);
    printf("\n\tNormal: %d", normal);

    // Print number of tasks for each developer
    printf("\nNumber of Tasks for each Developer:\n");
    for (int i = 0; i < noOfDevelopers; i++) {
        printf("\tDeveloper %d Accomplished: %d\n", i + 1, developers[i]);
    }
    printf("*Completion time: %d",time);
    // Calculate and print average time spent in the queue if there are tasks
    if (noOfTasks > 0) {
        printf("\n*Average time spent in the queue: %.2f", (float)waitTime / noOfTasks);
    }
    printf("\n*Maximum waiting time: %d\n", maxWaitTime);
}


void newTaskFunction(List taskList, Queue taskQueue) {
    // Enqueue tasks from taskList to taskQueue
    struct Node *p;
    p = taskList->head->next;
    while (p != NULL) {
        Enqueue(taskQueue, p->taskType, p->arrivalTime, p->serviceTime, p->serviceStartTime, p->ID);
        p = p->next;
    }

    // Sort tasks in taskList by taskType in descending order
    struct Node *current = taskList->head->next;
    while (current != NULL) {
        struct Node *otherTmp = current->next;
        while (otherTmp != NULL) {
            if (current->taskType < otherTmp->taskType) {
                // Swap the data of current and otherTmp nodes
                int tmpTaskType = current->taskType;
                int tmpArrivalTime = current->arrivalTime;
                int tmpServiceTime = current->serviceTime;
                int tmpServiceStartTime = current->serviceStartTime;
                int tmpID = current->ID;

                current->taskType = otherTmp->taskType;
                current->arrivalTime = otherTmp->arrivalTime;
                current->serviceTime = otherTmp->serviceTime;
                current->serviceStartTime = otherTmp->serviceStartTime;
                current->ID = otherTmp->ID;

                otherTmp->taskType = tmpTaskType;
                otherTmp->arrivalTime = tmpArrivalTime;
                otherTmp->serviceTime = tmpServiceTime;
                otherTmp->serviceStartTime = tmpServiceStartTime;
                otherTmp->ID = tmpID;
            }
            otherTmp = otherTmp->next;
        }
        current = current->next;
    }
}


void accomplishTask(Queue taskQueue) {
    if (!IsEmptyQueue(taskQueue)) {
        struct Node *removedNode = Dequeue(taskQueue);

        if (removedNode != NULL) {
            // printf("Task accomplished:\n");
            // printf("Task Type: %d\n", removedNode->taskType);
            // printf("Arrival Time: %d\n", removedNode->arrivalTime);
            // printf("Service Time: %d\n", removedNode->serviceTime);
            // printf("Service Start Time: %d\n", removedNode->serviceStartTime);
            // printf("ID: %d\n", removedNode->ID);

            free(removedNode);
        } else {
            printf("Error in removing the task from the queue!\n");
        }
    } else {
        printf("The queue is empty!\n");
    }
}


