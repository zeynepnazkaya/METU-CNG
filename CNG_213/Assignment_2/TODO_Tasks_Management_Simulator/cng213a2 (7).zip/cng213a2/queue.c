//Tasks Management Simulator-queue.c
//Name & Surname: Zeynep Naz Kaya
//ID: 2526481
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "queue.h"

#define YES	1
#define	NO	0


//For creating queue I didn't use this because its complicated for me so I create them inside functions, but here you can see other way.
Queue CreateQueue() {
    Queue queue = (Queue)malloc(sizeof(struct QueueRecord));
    if (queue == NULL) {
        printf("Memory allocation error!\n");
        exit(EXIT_FAILURE);
    }
    queue->head = NULL;
    queue->tail = NULL;
    queue->sizeOfQueue = 0;
    return queue;
}


int IsEmptyQueue(struct QueueRecord *queue)
{
    if(queue->head==NULL){
        return YES;
    }
    return NO;
}


// Function to add an element to the queue
void Enqueue(Queue taskQueue, int taskType, int arrivalTime, int serviceTime, int serviceStartTime, int ID) {
    // Check if the queue is initialized
    if (taskQueue == NULL) {
        printf("Queue is not initialized!\n");
        return;
    }

    // Allocate memory for the new node
    struct Node *tmp;
    tmp = (struct Node*)malloc(sizeof(struct Node));
    if (tmp == NULL) {
        printf("\nAllocation Error!\n");
        exit(1);
    }

    // Assign values to the new node
    tmp->taskType = taskType;
    tmp->arrivalTime = arrivalTime;
    tmp->serviceTime = serviceTime;
    tmp->serviceStartTime = serviceStartTime;
    tmp->ID = ID;
    tmp->next = NULL;

    // Check if the queue is empty
    if (taskQueue->head == NULL) {
        // If the queue is empty, set both head and tail to the new node
        taskQueue->head = tmp;
        taskQueue->tail = tmp;
    } else {
        // Otherwise, add the new node to the end of the queue
        taskQueue->tail->next = tmp;
        taskQueue->tail = tmp;
    }
    taskQueue->sizeOfQueue++; // Increase the size of the queue
}


// Function to remove an element from the queue
struct Node* Dequeue(Queue taskQueue) {
    if (taskQueue == NULL || taskQueue->sizeOfQueue == 0) {
        printf("\nQueue is empty / not initialized correctly!\n");
        return NULL;
    }

    struct Node *removedNode = NULL;
    struct Node *tempNode = taskQueue->head->next; // Here, this storing the first element of the queue temporarily

    if (tempNode != NULL) {
        removedNode = (struct Node*)malloc(sizeof(struct Node)); // Create a new node to hold the removed item from the queue
        if (removedNode == NULL) {
            printf("\nAllocation Error!\n");
            exit(1);
        }

        // Copy data to the removed node
        removedNode->taskType = tempNode->taskType;
        removedNode->arrivalTime = tempNode->arrivalTime;
        removedNode->serviceTime = tempNode->serviceTime;
        removedNode->serviceStartTime = tempNode->serviceStartTime;
        removedNode->ID = tempNode->ID;
        removedNode->next = NULL; //Set removedNode's next pointer to NULL

        taskQueue->head->next = tempNode->next; // Disconnect the removed node from the queue
        free(tempNode);// Free the removed node
        taskQueue->sizeOfQueue--;

        if (taskQueue->sizeOfQueue == 0) {
            taskQueue->tail = taskQueue->head;// If the queue becomes empty, set the tail to point to the head
        }
    }

    return removedNode;
}


void MakeEmptyQueue(Queue *queue) {
    while (!IsEmptyQueue(queue)) {
        Dequeue(queue);
    }
}